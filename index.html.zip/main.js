let first= 5
let sec= 10
first++
sec--
let total= ++first + sec 
console.log(total)